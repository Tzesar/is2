The font of this directory have not been included into the SVN
because of copyright issues. The names of the fonts are:

- CODE2000 (TTF)
- DejaVu (TTF)
- Forelle (AFM + PFB)
- leerc (AFM + PFB)
- milano (TTF)
- rina (TTF)
