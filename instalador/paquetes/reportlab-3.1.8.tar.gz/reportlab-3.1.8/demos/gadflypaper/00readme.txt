This is Aaron Watters' first script;
it renders his paper for IPC8 into
PDF. A fascinating read, as well.